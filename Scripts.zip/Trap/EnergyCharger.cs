﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnergyCharger : MonoBehaviour
{
  
   
    void Start()
    {
       
    }

    
    void Update()
    {
        
    }


}
