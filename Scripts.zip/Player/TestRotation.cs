﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class TestRotation : MonoBehaviour
{
    public FixedJoystick _rjoystick;
    float _angel;
    Vector2 _targer, _mouse;
    //bool _right = true;
    public Tilemap _tilemap;
    void Start()
    {
        _targer = transform.position;
    }

    
    void Update()
    {
        MouseRotation();
    }

    public void MouseRotation()
    {
        float h = _rjoystick.Horizontal;
        float v = _rjoystick.Vertical;
        //Debug.Log("h " + h);
        //Debug.Log("v" + v);

        
        _angel = Mathf.Atan2(v, h) * Mathf.Rad2Deg;

        /*
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        Debug.DrawRay(ray.origin, ray.direction * 10, Color.blue, 3.5f);

        RaycastHit2D hit = Physics2D.Raycast(ray.origin, Vector3.zero);

        if (this._tilemap = hit.transform.GetComponent<Tilemap>())
        {
            this._tilemap.RefreshAllTiles();

            int x, y;
            x = this._tilemap.WorldToCell(ray.origin).x;
            y = this._tilemap.WorldToCell(ray.origin).y;

            Vector3Int v3Int = new Vector3Int(x, y, 0);



            //타일 색 바꿀 때 이게 있어야 하더군요
            this._tilemap.SetTileFlags(v3Int, TileFlags.None);

            //타일 색 바꾸기
            this._tilemap.SetColor(v3Int, (Color.red));

        }
        */



        //_mouse = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        //_angel = Mathf.Atan2(_mouse.y - _targer.y, _mouse.x - _targer.x) * Mathf.Rad2Deg;
        // Debug.Log("angle: " + _angel);

        //float mousePosX = _mouse.x;
        //float playerPosX = transform.position.x;
        //if( mousePosX < playerPosX )
        if ( h < 0 )
        {
            if (Char2D.Ins.Right == true)
                Char2D.Ins.Flip(false);
        }
        //if( playerPosX < mousePosX )
        if( h > 0 )
        {
            if (Char2D.Ins.Right == false)
                Char2D.Ins.Flip(true);
        }
            
        float _limitAngle = 45.0f;

        
        if(_limitAngle < _angel && _angel < 180 - _limitAngle ||
            -1 * (180-_limitAngle) < _angel && _angel < -1 * _limitAngle )
        {

        }
        else
        {
            

            if( Char2D.Ins.Right == false && 
                (( (180 - _limitAngle) <= _angel && _angel <= 180) ||
                  (-1 * (180 - _limitAngle) >= _angel && _angel >= -180))
            )
            {
                transform.rotation = Quaternion.AngleAxis(_angel + 90, Vector3.forward);
            }


            if( Char2D.Ins.Right && _limitAngle > _angel && _angel > -1 * _limitAngle
            )
            {
                transform.rotation = Quaternion.AngleAxis(_angel + 90, Vector3.forward);
            }


        }

        
    }
}
