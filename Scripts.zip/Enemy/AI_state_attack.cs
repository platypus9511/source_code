﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_state_attack : AI_state
{
    protected override void OnEnable()
    {
        //_anim.SetTrigger("attack");
    }
}
