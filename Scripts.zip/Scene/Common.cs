﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum SCENE
{
    
    TITTLE =0,
    GAME,
    GAME2,
  



}

public class Common
{
    public const string BTN_SETTING = "setting";
    public const string BTN_SOUND = "menuBtnSound";
    public const string BTN_TITTLE = "Quit";
    public const string BTN_BACK = "back";
    public const string BTN_RESTART = "restart";
    public const string BTN_GAME = "menuBtnGame";
    public const string BTN_OPTION = "menuBtnOption";
    public const string BTN_QUIT = "menuBtnQuit";
    public const string BTN_NEWG = "newgame";
    public const string BTN_STAGE = "stage";
    public const string BTN_LOAD = "loadgame";
}
